const express = require("express");
const cors = require("cors");
const path = require('path');

// Import routes
const userRoutes = require("./routes/users");
const userGroupRoutes = require("./routes/userGroups");
const userTypeRoutes = require("./routes/userTypes");
const groupPermissionRoutes = require("./routes/groupPermissions");
const pagePermissionRoutes = require("./routes/pagePermissions");
const programRoutes = require("./routes/programs");
const vehicleRoutes = require("./routes/vehicles");
const maintenanceRoutes = require("./routes/maintenance");
const vehiclePartsRoutes = require("./routes/vehicleParts");
const vehicleServicesRoutes = require("./routes/vehicleServices");
const partsSuppliersRoutes = require("./routes/partsSuppliers");
const documentRoutes = require("./routes/documents");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));  // Serve static files
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

// Test route to verify server is running
app.get("/", (req, res) => {
  res.json({ message: "Server is running" });
});

// Routes
app.use("/api/users", userRoutes);
app.use("/api/user-groups", userGroupRoutes);
app.use("/api/user-types", userTypeRoutes);
app.use("/api/group-permissions", groupPermissionRoutes);
app.use("/api/page-permissions", pagePermissionRoutes);
app.use("/api/programs", programRoutes);
app.use("/api/vehicles", vehicleRoutes);
app.use("/api/maintenance", maintenanceRoutes);
app.use("/api/vehicle-parts", vehiclePartsRoutes);
app.use("/api/vehicle-services", vehicleServicesRoutes);
app.use("/api/parts-suppliers", partsSuppliersRoutes);
app.use("/api/documents", documentRoutes);

// Debug middleware to log requests
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Error:", err);
  res.status(500).json({ 
    message: "Something went wrong!", 
    error: err.message 
  });
});

module.exports = app; 