-- First modify the existing columns to be integers
ALTER TABLE users
MODIFY COLUMN user_type int(11),
MODIFY COLUMN user_group int(11);

-- Update the columns with corresponding IDs
UPDATE users u
JOIN user_types ut ON u.user_type = ut.type_name
SET u.user_type = ut.type_id;

UPDATE users u
JOIN user_groups ug ON u.user_group = ug.common_name
SET u.user_group = ug.group_id;

-- Add foreign key constraints
ALTER TABLE users
ADD CONSTRAINT fk_user_type
FOREIGN KEY (user_type) REFERENCES user_types(type_id);

ALTER TABLE users
ADD CONSTRAINT fk_user_group
FOREIGN KEY (user_group) REFERENCES user_groups(group_id); 