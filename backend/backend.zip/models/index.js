const User = require('./User');
const UserGroup = require('./UserGroup');
const UserType = require('./UserType');
const GroupPermission = require('./GroupPermission');
const Vehicle = require('./Vehicle');
const { 
  Maintenance, 
  VehiclePart, 
  VehicleService, 
  MaintenancePart, 
  MaintenanceService 
} = require('./Maintenance');

// Export all models
module.exports = {
  User,
  UserGroup,
  UserType,
  GroupPermission,
  Vehicle,
  Maintenance,
  VehiclePart,
  VehicleService,
  MaintenancePart,
  MaintenanceService
}; 