const express = require("express");
const router = express.Router();
const Program = require("../models/Program");
const { ValidationError } = require("sequelize");

// Get all programs
router.get("/", async (req, res) => {
  try {
    const programs = await Program.findAll();
    res.json(programs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create a new program
router.post("/", async (req, res) => {
  try {
    const newProgram = await Program.create({
      ...req.body,
      created_at: new Date(),
      updated_at: new Date(),
    });
    res.status(201).json(newProgram);
  } catch (error) {
    if (error instanceof ValidationError) {
      return res.status(400).json({
        message: "Validation failed",
        errors: error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        })),
      });
    }
    res.status(400).json({ message: error.message });
  }
});

// Update a program
router.put("/:id", async (req, res) => {
  try {
    const program = await Program.findByPk(req.params.id);
    if (!program) return res.status(404).json({ message: "Program not found" });

    await program.update(req.body);
    res.json(program);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete a program
router.delete("/:id", async (req, res) => {
  try {
    const program = await Program.findByPk(req.params.id);
    if (!program) return res.status(404).json({ message: "Program not found" });

    await program.destroy();
    res.json({ message: "Program deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router; 