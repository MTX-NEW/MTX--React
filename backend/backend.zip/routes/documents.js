const express = require("express");
const router = express.Router();
const Vehicle = require("../models/Vehicle");
const { Document } = require("../models/Document");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");

// Define uploads directory path
const uploadsDir = path.join(__dirname, '../public/uploads');

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure storage with error handling
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    try {
      // Log the request body to debug
      console.log('Request body:', req.body);
      
      const { documentable_type, documentable_id } = req.body;
      
      if (!documentable_type || !documentable_id) {
        console.error('Missing fields:', { documentable_type, documentable_id });
        return cb(new Error('Missing documentable type or ID'));
      }

      const dir = path.join(
        uploadsDir,
        documentable_type.toLowerCase(),
        documentable_id.toString()
      );
      
      // Log the directory being created
      console.log('Creating directory:', dir);
      
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    } catch (error) {
      console.error('Storage error:', error);
      cb(error);
    }
  },
  filename: function (req, file, cb) {
    try {
      const uniqueSuffix = Date.now() + '-' + uuidv4();
      const ext = path.extname(file.originalname);
      cb(null, uniqueSuffix + ext);
    } catch (error) {
      cb(error);
    }
  }
});

// Configure multer with limits and file filter
const upload = multer({
  storage: storage,
  limits: { 
    fileSize: 5 * 1024 * 1024, // 5MB limit
    files: 1 // Only allow 1 file per request
  },
  fileFilter: (req, file, cb) => {
    try {
      const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only JPEG, PNG, and PDF are allowed.'));
      }
    } catch (error) {
      cb(error);
    }
  }
});

// Update the route to use the handleUpload middleware
router.post("/", (req, res) => {
  upload.single('document')(req, res, async (err) => {
    if (err) {
      console.error('Upload error:', err);
      return res.status(400).json({
        message: 'Upload error',
        error: err.message
      });
    }

    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      console.log('File received:', req.file);
      console.log('Form data:', req.body);

      const { documentable_type, documentable_id } = req.body;
      if (!documentable_type || !documentable_id) {
        if (req.file.path) {
          fs.unlinkSync(req.file.path);
        }
        return res.status(400).json({ message: 'Missing required fields' });
      }

      const relativePath = path.relative(
        path.join(__dirname, '../public'), 
        req.file.path
      ).replace(/\\/g, '/'); // Convert to forward slashes

      const document = await Document.create({
        documentable_type,
        documentable_id,
        filename: req.file.filename,
        original_name: req.file.originalname,
        path: relativePath, // Store relative path from public directory
        mime_type: req.file.mimetype,
        size: req.file.size
      });

      res.status(201).json({
        message: 'Document uploaded successfully',
        document
      });
    } catch (error) {
      console.error("Upload error:", error);
      // Clean up the uploaded file if database operation fails
      if (req.file && req.file.path) {
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ 
        message: "Document upload failed",
        error: error.message
      });
    }
  });
});

// Add this route if missing
router.get("/:type/:id", async (req, res) => {
  try {
    const documents = await Document.findAll({
      where: { 
        documentable_type: req.params.type,
        documentable_id: req.params.id
      }
    });
    res.json(documents);
  } catch (error) {
    console.error("Error fetching documents:", error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;