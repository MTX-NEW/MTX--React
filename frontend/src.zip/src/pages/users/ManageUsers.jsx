import { useResource } from "@/hooks/useResource";

const { 
  data: managedUsers,
  // ... other hook properties
} = useResource('managed-users'); // Replace with actual endpoint
