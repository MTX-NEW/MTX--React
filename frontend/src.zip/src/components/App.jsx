import GlobalStyles from "./common/GlobalStyles";

function App() {
  return (
    <Router>
      <GlobalStyles />
    </Router>
  );
}

export default App; 