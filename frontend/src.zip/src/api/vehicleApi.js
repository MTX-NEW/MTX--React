import { createApi } from '@/api/baseApi';

export default createApi('vehicles'); 